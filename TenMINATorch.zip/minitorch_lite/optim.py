"""
MiniTorch Lite - Optimizers Module
==================================
Módulo de optimizadores para entrenamiento de redes neuronales.
"""

import numpy as np
from typing import List, Dict, Any, Optional
from .tensor import Tensor

class Optimizer:
    """
    Clase base para todos los optimizadores.
    """
    
    def __init__(self, params: List[Tensor], lr: float = 0.01):
        self.params = params
        self.lr = lr
        self.state: Dict[int, Dict[str, Any]] = {}
    
    def step(self):
        """Actualiza los parámetros."""
        raise NotImplementedError
    
    def zero_grad(self):
        """Resetea los gradientes de todos los parámetros."""
        for param in self.params:
            param.zero_grad()
    
    def state_dict(self) -> Dict[str, Any]:
        """Retorna el estado del optimizador."""
        return {
            'lr': self.lr,
            'state': {str(k): v for k, v in self.state.items()}
        }
    
    def load_state_dict(self, state_dict: Dict[str, Any]):
        """Carga el estado del optimizador."""
        self.lr = state_dict.get('lr', self.lr)
        self.state = {int(k): v for k, v in state_dict.get('state', {}).items()}

class SGD(Optimizer):
    """
    Stochastic Gradient Descent con momentum opcional.
    
    Args:
        params: Lista de parámetros a optimizar
        lr: Learning rate (tasa de aprendizaje)
        momentum: Factor de momentum (0 = sin momentum)
        weight_decay: Factor de regularización L2
        nesterov: Usar momentum de Nesterov
    """
    
    def __init__(self, params: List[Tensor], lr: float = 0.01, 
                 momentum: float = 0.0, weight_decay: float = 0.0,
                 nesterov: bool = False):
        super().__init__(params, lr)
        self.momentum = momentum
        self.weight_decay = weight_decay
        self.nesterov = nesterov
    
    def step(self):
        for i, param in enumerate(self.params):
            if param.grad is None:
                continue
            
            grad = param.grad
            
            # Weight decay (L2 regularization)
            if self.weight_decay != 0:
                grad = grad + self.weight_decay * param.data
            
            # Momentum
            if self.momentum != 0:
                if i not in self.state:
                    self.state[i] = {'velocity': np.zeros_like(param.data)}
                
                v = self.state[i]['velocity']
                v = self.momentum * v + grad
                self.state[i]['velocity'] = v
                
                if self.nesterov:
                    grad = grad + self.momentum * v
                else:
                    grad = v
            
            # Actualizar parámetro
            param.data = param.data - self.lr * grad

class Adam(Optimizer):
    """
    Adam optimizer (Adaptive Moment Estimation).
    
    Args:
        params: Lista de parámetros a optimizar
        lr: Learning rate
        betas: Coeficientes para promedios móviles (beta1, beta2)
        eps: Término de estabilidad numérica
        weight_decay: Factor de regularización L2
    """
    
    def __init__(self, params: List[Tensor], lr: float = 0.001,
                 betas: tuple = (0.9, 0.999), eps: float = 1e-8,
                 weight_decay: float = 0.0):
        super().__init__(params, lr)
        self.betas = betas
        self.eps = eps
        self.weight_decay = weight_decay
        self.t = 0  # Contador de pasos
    
    def step(self):
        self.t += 1
        
        for i, param in enumerate(self.params):
            if param.grad is None:
                continue
            
            grad = param.grad
            
            # Weight decay
            if self.weight_decay != 0:
                grad = grad + self.weight_decay * param.data
            
            # Inicializar estado
            if i not in self.state:
                self.state[i] = {
                    'm': np.zeros_like(param.data),  # Primer momento
                    'v': np.zeros_like(param.data)   # Segundo momento
                }
            
            m, v = self.state[i]['m'], self.state[i]['v']
            beta1, beta2 = self.betas
            
            # Actualizar momentos
            m = beta1 * m + (1 - beta1) * grad
            v = beta2 * v + (1 - beta2) * (grad ** 2)
            
            self.state[i]['m'] = m
            self.state[i]['v'] = v
            
            # Corrección de sesgo
            m_hat = m / (1 - beta1 ** self.t)
            v_hat = v / (1 - beta2 ** self.t)
            
            # Actualizar parámetro
            param.data = param.data - self.lr * m_hat / (np.sqrt(v_hat) + self.eps)

class AdamW(Optimizer):
    """
    AdamW optimizer (Adam con weight decay desacoplado).
    
    Args:
        params: Lista de parámetros a optimizar
        lr: Learning rate
        betas: Coeficientes para promedios móviles
        eps: Término de estabilidad numérica
        weight_decay: Factor de weight decay
    """
    
    def __init__(self, params: List[Tensor], lr: float = 0.001,
                 betas: tuple = (0.9, 0.999), eps: float = 1e-8,
                 weight_decay: float = 0.01):
        super().__init__(params, lr)
        self.betas = betas
        self.eps = eps
        self.weight_decay = weight_decay
        self.t = 0
    
    def step(self):
        self.t += 1
        
        for i, param in enumerate(self.params):
            if param.grad is None:
                continue
            
            grad = param.grad
            
            # Inicializar estado
            if i not in self.state:
                self.state[i] = {
                    'm': np.zeros_like(param.data),
                    'v': np.zeros_like(param.data)
                }
            
            m, v = self.state[i]['m'], self.state[i]['v']
            beta1, beta2 = self.betas
            
            # Actualizar momentos
            m = beta1 * m + (1 - beta1) * grad
            v = beta2 * v + (1 - beta2) * (grad ** 2)
            
            self.state[i]['m'] = m
            self.state[i]['v'] = v
            
            # Corrección de sesgo
            m_hat = m / (1 - beta1 ** self.t)
            v_hat = v / (1 - beta2 ** self.t)
            
            # Weight decay desacoplado
            param.data = param.data - self.weight_decay * self.lr * param.data
            
            # Actualizar parámetro
            param.data = param.data - self.lr * m_hat / (np.sqrt(v_hat) + self.eps)

class RMSprop(Optimizer):
    """
    RMSprop optimizer.
    
    Args:
        params: Lista de parámetros a optimizar
        lr: Learning rate
        alpha: Factor de suavizado
        eps: Término de estabilidad numérica
        weight_decay: Factor de regularización L2
        momentum: Factor de momentum
    """
    
    def __init__(self, params: List[Tensor], lr: float = 0.01,
                 alpha: float = 0.99, eps: float = 1e-8,
                 weight_decay: float = 0.0, momentum: float = 0.0):
        super().__init__(params, lr)
        self.alpha = alpha
        self.eps = eps
        self.weight_decay = weight_decay
        self.momentum = momentum
    
    def step(self):
        for i, param in enumerate(self.params):
            if param.grad is None:
                continue
            
            grad = param.grad
            
            # Weight decay
            if self.weight_decay != 0:
                grad = grad + self.weight_decay * param.data
            
            # Inicializar estado
            if i not in self.state:
                self.state[i] = {
                    'square_avg': np.zeros_like(param.data),
                    'momentum_buffer': np.zeros_like(param.data)
                }
            
            square_avg = self.state[i]['square_avg']
            
            # Actualizar promedio de cuadrados
            square_avg = self.alpha * square_avg + (1 - self.alpha) * (grad ** 2)
            self.state[i]['square_avg'] = square_avg
            
            # Calcular actualización
            avg = np.sqrt(square_avg) + self.eps
            
            if self.momentum > 0:
                buf = self.state[i]['momentum_buffer']
                buf = self.momentum * buf + grad / avg
                self.state[i]['momentum_buffer'] = buf
                param.data = param.data - self.lr * buf
            else:
                param.data = param.data - self.lr * grad / avg

# --- Learning Rate Schedulers ---

class LRScheduler:
    """
    Clase base para schedulers de learning rate.
    """
    
    def __init__(self, optimizer: Optimizer):
        self.optimizer = optimizer
        self.base_lr = optimizer.lr
        self.last_epoch = 0
    
    def step(self, epoch: Optional[int] = None):
        """Actualiza el learning rate."""
        if epoch is None:
            epoch = self.last_epoch + 1
        self.last_epoch = epoch
        self._update_lr()
    
    def _update_lr(self):
        raise NotImplementedError
    
    def get_lr(self) -> float:
        return self.optimizer.lr

class StepLR(LRScheduler):
    """
    Reduce el learning rate por un factor cada N épocas.
    """
    
    def __init__(self, optimizer: Optimizer, step_size: int, gamma: float = 0.1):
        super().__init__(optimizer)
        self.step_size = step_size
        self.gamma = gamma
    
    def _update_lr(self):
        if self.last_epoch > 0 and self.last_epoch % self.step_size == 0:
            self.optimizer.lr = self.optimizer.lr * self.gamma

class ExponentialLR(LRScheduler):
    """
    Reduce el learning rate exponencialmente cada época.
    """
    
    def __init__(self, optimizer: Optimizer, gamma: float = 0.95):
        super().__init__(optimizer)
        self.gamma = gamma
    
    def _update_lr(self):
        self.optimizer.lr = self.base_lr * (self.gamma ** self.last_epoch)

class CosineAnnealingLR(LRScheduler):
    """
    Cosine annealing scheduler.
    """
    
    def __init__(self, optimizer: Optimizer, T_max: int, eta_min: float = 0):
        super().__init__(optimizer)
        self.T_max = T_max
        self.eta_min = eta_min
    
    def _update_lr(self):
        self.optimizer.lr = self.eta_min + (self.base_lr - self.eta_min) * \
                           (1 + np.cos(np.pi * self.last_epoch / self.T_max)) / 2
