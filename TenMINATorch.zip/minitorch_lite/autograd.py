"""
MiniTorch Lite - Autograd Module
================================
Motor de diferenciación automática con soporte para múltiples backends.
"""

import numpy as np
from . import backends as B

class Function:
    """
    Clase base para todas las operaciones de autograd.
    """
    
    @staticmethod
    def forward(ctx, *args):
        raise NotImplementedError
        
    @staticmethod
    def backward(ctx, grad_output):
        raise NotImplementedError
        
    @classmethod
    def apply(cls, *args):
        # Importación local para evitar ciclo
        from .tensor import Tensor
        
        input_tensors = [t for t in args if isinstance(t, Tensor)]
        requires_grad = any(t.requires_grad for t in input_tensors)
        
        ctx = Context()
        
        # 1. Extraer los datos (NumPy arrays o escalares) para el forward
        forward_args = []
        for t in args:
            if isinstance(t, Tensor):
                forward_args.append(np.asarray(t.data))
            elif isinstance(t, (int, float)):
                forward_args.append(np.asarray(t, dtype=np.float32))
            elif isinstance(t, np.ndarray):
                forward_args.append(t)
            else:
                forward_args.append(np.asarray(t, dtype=np.float32))
                
        # Ejecuta la función forward
        output_data = cls.forward(ctx, *forward_args)
        
        # 2. Guardar los argumentos originales (tensores o escalares) para el backward
        ctx.save_for_backward(*args)

        # 3. Crear el tensor de salida
        output_tensor = Tensor(output_data, requires_grad=requires_grad)
        
        # 4. Adjuntar la función de gradiente si es necesario
        if requires_grad:
            ctx.parents = input_tensors
            output_tensor.grad_fn = (cls, ctx)
            
        return output_tensor

class Context:
    def __init__(self):
        self.parents = []
        self.saved_tensors = []
        
    def save_for_backward(self, *args):
        self.saved_tensors = args

# --- Implementación de Operaciones Básicas ---

class MatMul(Function):
    @staticmethod
    def forward(ctx, a, b):
        # Usar el backend para la operación
        return B.matmul(a, b)

    @staticmethod
    def backward(ctx, grad_output):
        from .tensor import Tensor
        a, b = ctx.saved_tensors
        
        # Extraer los datos de NumPy de los tensores guardados
        a_data = np.asarray(a.data) if isinstance(a, Tensor) else np.asarray(a)
        b_data = np.asarray(b.data) if isinstance(b, Tensor) else np.asarray(b)
        
        # Gradiente para a: grad_output @ b.T
        grad_a = B.matmul(grad_output, B.transpose(b_data))
        
        # Gradiente para b: a.T @ grad_output
        grad_b = B.matmul(B.transpose(a_data), grad_output)
        
        return grad_a, grad_b

class Add(Function):
    @staticmethod
    def forward(ctx, a, b):
        return B.add(a, b)
        
    @staticmethod
    def backward(ctx, grad_output):
        # Para la suma, el gradiente es simplemente el gradiente de salida
        grads = []
        for parent in ctx.parents:
            if hasattr(parent, 'requires_grad') and parent.requires_grad:
                grads.append(grad_output)
        return tuple(grads) if grads else (grad_output, grad_output)

class Mul(Function):
    @staticmethod
    def forward(ctx, a, b):
        return B.multiply(a, b)
        
    @staticmethod
    def backward(ctx, grad_output):
        from .tensor import Tensor
        a, b = ctx.saved_tensors
        
        # Extraer los datos de NumPy de los tensores guardados
        a_data = np.asarray(a.data) if isinstance(a, Tensor) else np.asarray(a)
        b_data = np.asarray(b.data) if isinstance(b, Tensor) else np.asarray(b)
        
        # Gradiente para a: dL/dc * b
        grad_a = B.multiply(grad_output, b_data)
        
        # Gradiente para b: dL/dc * a
        grad_b = B.multiply(grad_output, a_data)
        
        # Devolver gradientes para todos los padres
        result = []
        for saved in ctx.saved_tensors:
            if isinstance(saved, Tensor) and saved.requires_grad:
                if saved is a or (hasattr(a, 'data') and np.array_equal(saved.data, a.data)):
                    result.append(grad_a)
                else:
                    result.append(grad_b)
            elif not isinstance(saved, Tensor):
                # Es un escalar, no necesita gradiente
                pass
                
        if not result:
            result = [grad_a]
            
        return tuple(result)

class Sum(Function):
    @staticmethod
    def forward(ctx, a):
        ctx.original_shape = a.shape
        return B.sum_array(a)
        
    @staticmethod
    def backward(ctx, grad_output):
        original_shape = ctx.original_shape
        # Si grad_output es un escalar, expandirlo
        if np.ndim(grad_output) == 0:
            grad_value = float(grad_output)
        else:
            grad_value = grad_output
        grad_a = B.full(original_shape, grad_value)
        return (grad_a,)

# --- Implementación de la Retropropagación (Backward) ---

def backward(tensor):
    """
    Ejecuta la retropropagación desde el tensor dado.
    """
    if not tensor.requires_grad:
        raise RuntimeError("El tensor no requiere gradiente.")
        
    if tensor.grad is None:
        tensor.grad = B.ones_like(tensor.data)
        
    functions_to_process = []
    visited = set()
    
    def traverse(t):
        if id(t) in visited:
            return
        visited.add(id(t))
        
        if t.grad_fn:
            functions_to_process.append(t)
            cls, ctx = t.grad_fn
            for parent in ctx.parents:
                if hasattr(parent, 'requires_grad') and parent.requires_grad:
                    traverse(parent)

    traverse(tensor)
    
    # Procesar en orden inverso (desde la salida hacia las entradas)
    for t in functions_to_process:
        cls, ctx = t.grad_fn
        input_grads = cls.backward(ctx, t.grad)
        
        # Asegurar que input_grads sea una tupla
        if not isinstance(input_grads, tuple):
            input_grads = (input_grads,)
        
        grad_idx = 0
        for parent in ctx.parents:
            if hasattr(parent, 'requires_grad') and parent.requires_grad:
                if grad_idx < len(input_grads):
                    grad = input_grads[grad_idx]
                    if parent.grad is None:
                        parent.grad = grad
                    else:
                        parent.grad = B.add(parent.grad, grad)
                    grad_idx += 1
