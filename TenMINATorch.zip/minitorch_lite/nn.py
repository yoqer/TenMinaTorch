"""
MiniTorch Lite - Neural Network Module
======================================
Módulo de redes neuronales con capas básicas y funciones de activación.
"""

import numpy as np
from typing import Optional, List, Dict, Any
from .tensor import Tensor
from . import backends as B

class Module:
    """
    Clase base para todos los módulos de red neuronal.
    Similar a torch.nn.Module y keras.Model.
    """
    
    def __init__(self):
        self._parameters: Dict[str, Tensor] = {}
        self._modules: Dict[str, 'Module'] = {}
        self._training = True
    
    def forward(self, x: Tensor) -> Tensor:
        raise NotImplementedError
    
    def __call__(self, x: Tensor) -> Tensor:
        return self.forward(x)
    
    def parameters(self) -> List[Tensor]:
        """Retorna todos los parámetros del módulo."""
        params = list(self._parameters.values())
        for module in self._modules.values():
            params.extend(module.parameters())
        return params
    
    def named_parameters(self) -> Dict[str, Tensor]:
        """Retorna todos los parámetros con sus nombres."""
        params = dict(self._parameters)
        for name, module in self._modules.items():
            for param_name, param in module.named_parameters().items():
                params[f"{name}.{param_name}"] = param
        return params
    
    def train(self, mode: bool = True):
        """Establece el modo de entrenamiento."""
        self._training = mode
        for module in self._modules.values():
            module.train(mode)
        return self
    
    def eval(self):
        """Establece el modo de evaluación."""
        return self.train(False)
    
    def state_dict(self) -> Dict[str, np.ndarray]:
        """Retorna el estado del módulo como diccionario."""
        state = {}
        for name, param in self.named_parameters().items():
            state[name] = param.data.copy()
        return state
    
    def load_state_dict(self, state_dict: Dict[str, np.ndarray]):
        """Carga el estado del módulo desde un diccionario."""
        for name, param in self.named_parameters().items():
            if name in state_dict:
                param.data = state_dict[name].copy()
    
    def zero_grad(self):
        """Resetea los gradientes de todos los parámetros."""
        for param in self.parameters():
            param.zero_grad()

class Parameter(Tensor):
    """
    Tensor que es un parámetro de un módulo.
    Por defecto requiere gradiente.
    """
    
    def __init__(self, data, requires_grad=True):
        super().__init__(data, requires_grad=requires_grad)

class Linear(Module):
    """
    Capa lineal (fully connected).
    y = x @ W.T + b
    """
    
    def __init__(self, in_features: int, out_features: int, bias: bool = True):
        super().__init__()
        
        # Inicialización Xavier/Glorot
        scale = np.sqrt(2.0 / (in_features + out_features))
        weight_data = np.random.randn(out_features, in_features).astype(np.float32) * scale
        
        self._parameters['weight'] = Parameter(weight_data)
        
        if bias:
            bias_data = np.zeros(out_features, dtype=np.float32)
            self._parameters['bias'] = Parameter(bias_data)
        
        self.in_features = in_features
        self.out_features = out_features
        self.use_bias = bias
    
    def forward(self, x: Tensor) -> Tensor:
        # x @ W.T
        weight = self._parameters['weight']
        output = x @ Tensor(weight.data.T, requires_grad=weight.requires_grad)
        
        if self.use_bias:
            bias = self._parameters['bias']
            output = output + bias
        
        return output

class ReLU(Module):
    """
    Función de activación ReLU.
    """
    
    def forward(self, x: Tensor) -> Tensor:
        # ReLU: max(0, x)
        output_data = np.maximum(0, x.data)
        output = Tensor(output_data, requires_grad=x.requires_grad)
        
        if x.requires_grad:
            # Guardar máscara para backward
            output._relu_mask = (x.data > 0).astype(np.float32)
        
        return output

class Sigmoid(Module):
    """
    Función de activación Sigmoid.
    """
    
    def forward(self, x: Tensor) -> Tensor:
        output_data = 1 / (1 + np.exp(-np.clip(x.data, -500, 500)))
        return Tensor(output_data, requires_grad=x.requires_grad)

class Tanh(Module):
    """
    Función de activación Tanh.
    """
    
    def forward(self, x: Tensor) -> Tensor:
        output_data = np.tanh(x.data)
        return Tensor(output_data, requires_grad=x.requires_grad)

class Softmax(Module):
    """
    Función de activación Softmax.
    """
    
    def __init__(self, dim: int = -1):
        super().__init__()
        self.dim = dim
    
    def forward(self, x: Tensor) -> Tensor:
        # Estabilidad numérica: restar el máximo
        exp_x = np.exp(x.data - np.max(x.data, axis=self.dim, keepdims=True))
        output_data = exp_x / np.sum(exp_x, axis=self.dim, keepdims=True)
        return Tensor(output_data, requires_grad=x.requires_grad)

class Dropout(Module):
    """
    Capa de Dropout para regularización.
    """
    
    def __init__(self, p: float = 0.5):
        super().__init__()
        self.p = p
    
    def forward(self, x: Tensor) -> Tensor:
        if self._training and self.p > 0:
            mask = (np.random.rand(*x.shape) > self.p).astype(np.float32)
            output_data = x.data * mask / (1 - self.p)
            return Tensor(output_data, requires_grad=x.requires_grad)
        return x

class Sequential(Module):
    """
    Contenedor secuencial de módulos.
    """
    
    def __init__(self, *modules):
        super().__init__()
        for i, module in enumerate(modules):
            self._modules[str(i)] = module
    
    def forward(self, x: Tensor) -> Tensor:
        for module in self._modules.values():
            x = module(x)
        return x
    
    def add(self, module: Module):
        """Añade un módulo al final de la secuencia."""
        idx = len(self._modules)
        self._modules[str(idx)] = module

# --- Funciones de Pérdida ---

class MSELoss(Module):
    """
    Error cuadrático medio (Mean Squared Error).
    """
    
    def forward(self, prediction: Tensor, target: Tensor) -> Tensor:
        diff = prediction.data - target.data
        loss_data = np.mean(diff ** 2)
        return Tensor(loss_data, requires_grad=prediction.requires_grad)

class CrossEntropyLoss(Module):
    """
    Pérdida de entropía cruzada.
    """
    
    def forward(self, prediction: Tensor, target: Tensor) -> Tensor:
        # Softmax + Cross Entropy
        exp_pred = np.exp(prediction.data - np.max(prediction.data, axis=-1, keepdims=True))
        softmax = exp_pred / np.sum(exp_pred, axis=-1, keepdims=True)
        
        # Evitar log(0)
        softmax = np.clip(softmax, 1e-10, 1.0)
        
        # Cross entropy
        if target.data.ndim == 1:
            # Target es índices de clase
            batch_size = prediction.data.shape[0]
            loss_data = -np.mean(np.log(softmax[np.arange(batch_size), target.data.astype(int)]))
        else:
            # Target es one-hot
            loss_data = -np.mean(np.sum(target.data * np.log(softmax), axis=-1))
        
        return Tensor(loss_data, requires_grad=prediction.requires_grad)

# --- Funciones de Inicialización ---

def xavier_init(shape, gain=1.0):
    """Inicialización Xavier/Glorot."""
    fan_in, fan_out = shape[0], shape[1] if len(shape) > 1 else shape[0]
    std = gain * np.sqrt(2.0 / (fan_in + fan_out))
    return np.random.randn(*shape).astype(np.float32) * std

def kaiming_init(shape, mode='fan_in'):
    """Inicialización Kaiming/He."""
    fan = shape[0] if mode == 'fan_in' else shape[1] if len(shape) > 1 else shape[0]
    std = np.sqrt(2.0 / fan)
    return np.random.randn(*shape).astype(np.float32) * std
