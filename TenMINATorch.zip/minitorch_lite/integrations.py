"""
MiniTorch Lite - External Integrations Module
=============================================
Módulo de integración con librerías externas para continuación de entrenamiento
y aceleración: Keras, TensorFlow, PyTorch, JAX, Numba, CuPy, NetworkX.
"""

import numpy as np
from typing import Optional, Dict, Any, Union
from pathlib import Path
import pickle
import json
import warnings

# --- Detección de Librerías Disponibles ---

HAS_TENSORFLOW = False
HAS_KERAS = False
HAS_PYTORCH = False
HAS_JAX = False
HAS_NETWORKX = False

try:
    import tensorflow as tf
    HAS_TENSORFLOW = True
    try:
        from tensorflow import keras
        HAS_KERAS = True
    except ImportError:
        pass
except ImportError:
    pass

try:
    import torch
    HAS_PYTORCH = True
except ImportError:
    pass

try:
    import jax
    import jax.numpy as jnp
    HAS_JAX = True
except ImportError:
    pass

try:
    import networkx as nx
    HAS_NETWORKX = True
except ImportError:
    pass

# --- Clase Base de Integración ---

class ExternalIntegration:
    """
    Clase base para integraciones con librerías externas.
    """
    
    @staticmethod
    def check_availability() -> Dict[str, bool]:
        """Verifica qué librerías están disponibles."""
        return {
            'tensorflow': HAS_TENSORFLOW,
            'keras': HAS_KERAS,
            'pytorch': HAS_PYTORCH,
            'jax': HAS_JAX,
            'networkx': HAS_NETWORKX
        }
    
    @staticmethod
    def print_availability():
        """Imprime el estado de disponibilidad de las librerías."""
        availability = ExternalIntegration.check_availability()
        print("=" * 50)
        print("MiniTorch Lite - Librerías Externas Disponibles")
        print("=" * 50)
        for lib, available in availability.items():
            status = "✓ Disponible" if available else "✗ No instalada"
            print(f"  {lib.capitalize()}: {status}")
        print("=" * 50)

# --- Integración con Keras ---

class KerasIntegration:
    """
    Integración con Keras para continuación de entrenamiento y transferencia de pesos.
    
    Uso:
        # Exportar pesos de MiniTorch a Keras
        keras_model = KerasIntegration.to_keras_model(minitorch_model, keras_model)
        
        # Importar pesos de Keras a MiniTorch
        minitorch_model = KerasIntegration.from_keras_model(keras_model, minitorch_model)
    """
    
    @staticmethod
    def to_keras_weights(weights: Dict[str, np.ndarray]) -> list:
        """
        Convierte pesos de MiniTorch a formato Keras.
        
        Args:
            weights: Diccionario de pesos de MiniTorch
        
        Returns:
            Lista de arrays para Keras
        """
        if not HAS_KERAS:
            raise ImportError("Keras no está instalado. Instala con: pip install tensorflow")
        
        return [np.array(w) for w in weights.values()]
    
    @staticmethod
    def from_keras_weights(keras_weights: list, weight_names: list) -> Dict[str, np.ndarray]:
        """
        Convierte pesos de Keras a formato MiniTorch.
        
        Args:
            keras_weights: Lista de arrays de Keras
            weight_names: Lista de nombres para los pesos
        
        Returns:
            Diccionario de pesos para MiniTorch
        """
        return {name: np.array(w) for name, w in zip(weight_names, keras_weights)}
    
    @staticmethod
    def create_keras_model_from_config(config: Dict[str, Any]):
        """
        Crea un modelo Keras desde una configuración de MiniTorch.
        
        Args:
            config: Configuración del modelo (capas, activaciones, etc.)
        
        Returns:
            Modelo Keras
        """
        if not HAS_KERAS:
            raise ImportError("Keras no está instalado. Instala con: pip install tensorflow")
        
        from tensorflow import keras
        
        model = keras.Sequential()
        
        for layer_config in config.get('layers', []):
            layer_type = layer_config.get('type', 'dense')
            
            if layer_type == 'dense':
                model.add(keras.layers.Dense(
                    units=layer_config.get('units', 64),
                    activation=layer_config.get('activation', 'relu'),
                    input_shape=layer_config.get('input_shape', None)
                ))
            elif layer_type == 'dropout':
                model.add(keras.layers.Dropout(rate=layer_config.get('rate', 0.5)))
            elif layer_type == 'batch_norm':
                model.add(keras.layers.BatchNormalization())
        
        return model
    
    @staticmethod
    def save_for_keras(weights: Dict[str, np.ndarray], filepath: str):
        """
        Guarda pesos en formato compatible con Keras.
        
        Args:
            weights: Diccionario de pesos
            filepath: Ruta del archivo
        """
        np.savez(filepath, **weights)
        print(f"[MiniTorch Lite] Pesos guardados para Keras: {filepath}")
    
    @staticmethod
    def load_from_keras(filepath: str) -> Dict[str, np.ndarray]:
        """
        Carga pesos desde un archivo compatible con Keras.
        
        Args:
            filepath: Ruta del archivo
        
        Returns:
            Diccionario de pesos
        """
        data = np.load(filepath)
        return {key: data[key] for key in data.files}

# --- Integración con PyTorch ---

class PyTorchIntegration:
    """
    Integración con PyTorch para continuación de entrenamiento y transferencia de pesos.
    """
    
    @staticmethod
    def to_pytorch_tensor(data: np.ndarray):
        """
        Convierte un array de NumPy a tensor de PyTorch.
        
        Args:
            data: Array de NumPy
        
        Returns:
            Tensor de PyTorch
        """
        if not HAS_PYTORCH:
            raise ImportError("PyTorch no está instalado. Instala con: pip install torch")
        
        import torch
        return torch.from_numpy(data)
    
    @staticmethod
    def from_pytorch_tensor(tensor) -> np.ndarray:
        """
        Convierte un tensor de PyTorch a array de NumPy.
        
        Args:
            tensor: Tensor de PyTorch
        
        Returns:
            Array de NumPy
        """
        if not HAS_PYTORCH:
            raise ImportError("PyTorch no está instalado. Instala con: pip install torch")
        
        return tensor.detach().cpu().numpy()
    
    @staticmethod
    def save_for_pytorch(weights: Dict[str, np.ndarray], filepath: str):
        """
        Guarda pesos en formato compatible con PyTorch.
        
        Args:
            weights: Diccionario de pesos
            filepath: Ruta del archivo
        """
        if not HAS_PYTORCH:
            raise ImportError("PyTorch no está instalado. Instala con: pip install torch")
        
        import torch
        torch_weights = {k: torch.from_numpy(v) for k, v in weights.items()}
        torch.save(torch_weights, filepath)
        print(f"[MiniTorch Lite] Pesos guardados para PyTorch: {filepath}")
    
    @staticmethod
    def load_from_pytorch(filepath: str) -> Dict[str, np.ndarray]:
        """
        Carga pesos desde un archivo de PyTorch.
        
        Args:
            filepath: Ruta del archivo
        
        Returns:
            Diccionario de pesos
        """
        if not HAS_PYTORCH:
            raise ImportError("PyTorch no está instalado. Instala con: pip install torch")
        
        import torch
        torch_weights = torch.load(filepath, map_location='cpu')
        return {k: v.numpy() for k, v in torch_weights.items()}

# --- Integración con TensorFlow ---

class TensorFlowIntegration:
    """
    Integración con TensorFlow para continuación de entrenamiento.
    """
    
    @staticmethod
    def to_tf_tensor(data: np.ndarray):
        """
        Convierte un array de NumPy a tensor de TensorFlow.
        """
        if not HAS_TENSORFLOW:
            raise ImportError("TensorFlow no está instalado. Instala con: pip install tensorflow")
        
        import tensorflow as tf
        return tf.constant(data)
    
    @staticmethod
    def from_tf_tensor(tensor) -> np.ndarray:
        """
        Convierte un tensor de TensorFlow a array de NumPy.
        """
        if not HAS_TENSORFLOW:
            raise ImportError("TensorFlow no está instalado. Instala con: pip install tensorflow")
        
        return tensor.numpy()
    
    @staticmethod
    def save_for_tensorflow(weights: Dict[str, np.ndarray], filepath: str):
        """
        Guarda pesos en formato compatible con TensorFlow.
        """
        np.savez(filepath, **weights)
        print(f"[MiniTorch Lite] Pesos guardados para TensorFlow: {filepath}")

# --- Integración con JAX ---

class JAXIntegration:
    """
    Integración con JAX para aceleración y autograd avanzado.
    """
    
    @staticmethod
    def to_jax_array(data: np.ndarray):
        """
        Convierte un array de NumPy a array de JAX.
        """
        if not HAS_JAX:
            raise ImportError("JAX no está instalado. Instala con: pip install jax jaxlib")
        
        import jax.numpy as jnp
        return jnp.array(data)
    
    @staticmethod
    def from_jax_array(array) -> np.ndarray:
        """
        Convierte un array de JAX a array de NumPy.
        """
        if not HAS_JAX:
            raise ImportError("JAX no está instalado. Instala con: pip install jax jaxlib")
        
        return np.array(array)
    
    @staticmethod
    def jit_compile(func):
        """
        Compila una función con JAX JIT.
        """
        if not HAS_JAX:
            warnings.warn("JAX no está instalado. Retornando función sin compilar.")
            return func
        
        import jax
        return jax.jit(func)

# --- Clase Unificada de Exportación/Importación ---

class ModelExporter:
    """
    Clase unificada para exportar e importar modelos entre diferentes frameworks.
    
    Uso:
        exporter = ModelExporter()
        
        # Exportar a Keras
        exporter.export(weights, 'model.h5', format='keras')
        
        # Importar desde PyTorch
        weights = exporter.import_weights('model.pt', format='pytorch')
    """
    
    SUPPORTED_FORMATS = ['keras', 'pytorch', 'tensorflow', 'numpy', 'pickle']
    
    def __init__(self):
        self.integrations = {
            'keras': KerasIntegration,
            'pytorch': PyTorchIntegration,
            'tensorflow': TensorFlowIntegration,
            'jax': JAXIntegration
        }
    
    def export(self, weights: Dict[str, np.ndarray], filepath: str, format: str = 'numpy'):
        """
        Exporta pesos a un formato específico.
        
        Args:
            weights: Diccionario de pesos
            filepath: Ruta del archivo
            format: Formato de exportación ('keras', 'pytorch', 'tensorflow', 'numpy', 'pickle')
        """
        format = format.lower()
        
        if format == 'keras':
            KerasIntegration.save_for_keras(weights, filepath)
        elif format == 'pytorch':
            PyTorchIntegration.save_for_pytorch(weights, filepath)
        elif format == 'tensorflow':
            TensorFlowIntegration.save_for_tensorflow(weights, filepath)
        elif format == 'numpy':
            np.savez(filepath, **weights)
            print(f"[MiniTorch Lite] Pesos guardados en formato NumPy: {filepath}")
        elif format == 'pickle':
            with open(filepath, 'wb') as f:
                pickle.dump(weights, f)
            print(f"[MiniTorch Lite] Pesos guardados en formato Pickle: {filepath}")
        else:
            raise ValueError(f"Formato no soportado: {format}. Usa: {self.SUPPORTED_FORMATS}")
    
    def import_weights(self, filepath: str, format: str = 'numpy') -> Dict[str, np.ndarray]:
        """
        Importa pesos desde un archivo.
        
        Args:
            filepath: Ruta del archivo
            format: Formato del archivo ('keras', 'pytorch', 'tensorflow', 'numpy', 'pickle')
        
        Returns:
            Diccionario de pesos
        """
        format = format.lower()
        
        if format == 'keras':
            return KerasIntegration.load_from_keras(filepath)
        elif format == 'pytorch':
            return PyTorchIntegration.load_from_pytorch(filepath)
        elif format in ['tensorflow', 'numpy']:
            data = np.load(filepath)
            return {key: data[key] for key in data.files}
        elif format == 'pickle':
            with open(filepath, 'rb') as f:
                return pickle.load(f)
        else:
            raise ValueError(f"Formato no soportado: {format}. Usa: {self.SUPPORTED_FORMATS}")

# --- Función de Conveniencia ---

def print_integration_info():
    """Imprime información sobre las integraciones disponibles."""
    ExternalIntegration.print_availability()
