"""
MiniTorch Lite - Lightweight Deep Learning Library
==================================================

Una librería de deep learning ligera con soporte para:
- Autograd (diferenciación automática)
- Múltiples backends (NumPy, Numba, JAX, CuPy)
- Control de entrenamiento (Early Stopping, checkpoints)
- Integración con frameworks externos (Keras, PyTorch, TensorFlow)

Uso básico:
    import minitorch_lite as mtl
    
    # Crear tensores
    x = mtl.Tensor([[1, 2], [3, 4]], requires_grad=True)
    y = mtl.Tensor([[5, 6], [7, 8]], requires_grad=True)
    
    # Operaciones
    z = x @ y  # Multiplicación de matrices
    loss = z.sum()
    loss.backward()
    
    print(x.grad)  # Gradientes

Opciones de control de entrenamiento:
    - [NEW] Early Stop: Salto tras 12 iteraciones sin mejora
    - Límite de tokens: Corte automático a N tokens
    - Por defecto: Máximo 69 repeticiones

Backends disponibles:
    - numpy (por defecto)
    - numba (aceleración JIT)
    - jax (autograd avanzado)
    - cupy (GPU)

Autor: MiniTorch Lite Team
Versión: 0.1.0
"""

__version__ = "0.1.0"
__author__ = "MiniTorch Lite Team"

# --- Importaciones Principales ---
from .tensor import Tensor
from .backends import (
    set_backend,
    get_backend,
    get_available_backends,
    print_backend_info,
    HAS_NUMBA,
    HAS_JAX,
    HAS_CUPY,
    HAS_SCIPY
)

# --- Módulo de Autograd ---
from .autograd import (
    Function,
    Context,
    MatMul,
    Add,
    Mul,
    Sum,
    backward
)

# --- Módulo de Redes Neuronales ---
from .nn import (
    Module,
    Parameter,
    Linear,
    ReLU,
    Sigmoid,
    Tanh,
    Softmax,
    Dropout,
    Sequential,
    MSELoss,
    CrossEntropyLoss,
    xavier_init,
    kaiming_init
)

# --- Módulo de Optimizadores ---
from .optim import (
    Optimizer,
    SGD,
    Adam,
    AdamW,
    RMSprop,
    LRScheduler,
    StepLR,
    ExponentialLR,
    CosineAnnealingLR
)

# --- Módulo de Control de Entrenamiento ---
from .training import (
    TrainingConfig,
    TrainingState,
    TrainingController,
    create_training_controller
)

# --- Módulo de Integraciones ---
from .integrations import (
    ExternalIntegration,
    KerasIntegration,
    PyTorchIntegration,
    TensorFlowIntegration,
    JAXIntegration,
    ModelExporter,
    print_integration_info
)

# --- Exponer todo a nivel de paquete ---
__all__ = [
    # Tensor
    'Tensor',
    
    # Backends
    'set_backend',
    'get_backend',
    'get_available_backends',
    'print_backend_info',
    'HAS_NUMBA',
    'HAS_JAX',
    'HAS_CUPY',
    'HAS_SCIPY',
    
    # Autograd
    'Function',
    'Context',
    'MatMul',
    'Add',
    'Mul',
    'Sum',
    'backward',
    
    # Neural Networks
    'Module',
    'Parameter',
    'Linear',
    'ReLU',
    'Sigmoid',
    'Tanh',
    'Softmax',
    'Dropout',
    'Sequential',
    'MSELoss',
    'CrossEntropyLoss',
    'xavier_init',
    'kaiming_init',
    
    # Optimizers
    'Optimizer',
    'SGD',
    'Adam',
    'AdamW',
    'RMSprop',
    'LRScheduler',
    'StepLR',
    'ExponentialLR',
    'CosineAnnealingLR',
    
    # Training Control
    'TrainingConfig',
    'TrainingState',
    'TrainingController',
    'create_training_controller',
    
    # Integrations
    'ExternalIntegration',
    'KerasIntegration',
    'PyTorchIntegration',
    'TensorFlowIntegration',
    'JAXIntegration',
    'ModelExporter',
    'print_integration_info'
]
