"""
MiniTorch Lite - Tensor Module
==============================
Clase Tensor con soporte para autograd y múltiples backends.
"""

import numpy as np
from .autograd import MatMul, Add, Mul, Sum, backward

class Tensor:
    """
    Almacena datos multidimensionales y metadatos para el autograd.
    """
    
    def __init__(self, data, dtype=np.float32, requires_grad=False, grad_fn=None):
        # Asegurarse de que los datos son un array de NumPy
        if isinstance(data, Tensor):
            data = data.data.copy()
        elif isinstance(data, np.ndarray):
            data = data.astype(dtype)
        elif isinstance(data, (list, tuple)):
            data = np.array(data, dtype=dtype)
        elif isinstance(data, (int, float)):
            data = np.array(data, dtype=dtype)
        else:
            data = np.array(data, dtype=dtype)
            
        self.data = data
        self.dtype = dtype
        self.requires_grad = requires_grad
        self.grad = None
        self.grad_fn = grad_fn
        
    @property
    def shape(self):
        return self.data.shape
    
    @property
    def ndim(self):
        return self.data.ndim

    def __repr__(self):
        return f"Tensor({self.data}, requires_grad={self.requires_grad})"

    def __add__(self, other):
        return Add.apply(self, other)
    
    def __radd__(self, other):
        return Add.apply(self, other)

    def __mul__(self, other):
        return Mul.apply(self, other)

    def __rmul__(self, other):
        return Mul.apply(self, other)

    def __matmul__(self, other):
        return MatMul.apply(self, other)

    def sum(self):
        return Sum.apply(self)

    def backward(self):
        backward(self)
    
    def detach(self):
        """Crea un nuevo tensor sin conexión al grafo de gradientes."""
        return Tensor(self.data.copy(), dtype=self.dtype, requires_grad=False)
    
    def numpy(self):
        """Retorna los datos como array de NumPy."""
        return self.data.copy()
    
    def item(self):
        """Retorna el valor escalar si el tensor tiene un solo elemento."""
        return self.data.item()
    
    def zero_grad(self):
        """Resetea el gradiente a None."""
        self.grad = None
